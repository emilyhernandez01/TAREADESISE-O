<?php

	if ($_SERVER["REQUEST_METHOD"] == "POST") {

		if (!empty($_POST['Id_producto']) && (!empty($_POST['Nombre'])) && (!empty($_POST['Descripcion'])) && (!empty($_POST['Precio_costo'])) && (!empty($_POST['Precio_Venta'])) && (!empty($_POST['Stock']))) {

			$ID_PRODUCTO = $_POST['Id_producto'];
		$NOMBRE = $_POST['Nombre'];
		$DESCRIPCION = $_POST['Descripcion'];
		$PRECIO_COSTO = $_POST['Precio_costo'];
		$PRECIO_VENTA = $_POST['Precio_Venta'];
		$STOCK = $_POST['Stock'];


		$sql = $conexion->query("INSERT INTO tbl_productos(Id_producto, Nombre, Descripcion, Precio_costo, Precio_Venta, Stock) VALUES ('$ID_PRODUCTO','$NOMBRE','$DESCRIPCION','$PRECIO_COSTO','$PRECIO_VENTA','$STOCK')");

		if ($sql==1) {
			echo "<p class ='text-bg-success text-center'> Datos Guardados exitosamente</p>";
		}

		else{
			echo "<p class ='text-bg-danger text-center'>Usuario no Registrado</p>";
		}

			
		}
		
	}

 ?>
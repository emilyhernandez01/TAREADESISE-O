<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bp-local/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Listar Usuarios</title>
</head>
<body>
     <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Productos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registro_de_productos.php">Registrar Productos</a></li>
            <li><a class="dropdown-item" href="listar.php">Listado de Productos</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Movimientos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="movimientos.php">Registro de Movimiento</a></li>
            <li><a class="dropdown-item" href="verlistademovimiento.php">Lista de Movimientos</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav><div class="container">

    <h1 class="text-center">Listado de Movimientos</h1>
    <br><br>
    <table class="table">
            
        <tr>
            <th>Id movimiento</th>
            <th>Id Producto</th>
            <th>Fecha Movimiento</th>
            <th>Tipo Movimiento</th>
            <th>Cantidad</th>
            
            <th></th>
        </tr>
        <tr>
            
        </tr>
    <?php

    include("conexion.php");
    $sql = $conexion->query("SELECT * FROM tbl_movimientos");
    
    while ($usuarios = $sql->fetch_object()){
        
        echo "<tr>
        <td> $usuarios->Id_movimiento </td>
        <td> $usuarios->Id_producto </td>
        <td> $usuarios->Fecha_movimiento </td>
        <td> $usuarios->Tipo_movimiento </td>
        <td> $usuarios->Cantidad </td>
        <td> 
        
        </td>
    </tr>";


        }
    ?>
 </table>
    </div>

<script src="bp-local/js/bootstrap.bundle.min.js"></script>

</body>
</html>